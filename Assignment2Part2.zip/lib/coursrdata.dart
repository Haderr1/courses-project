class CourseData{
  String CourseImage;
  String CourseName;
  CourseData(this.CourseImage,this.CourseName);
}