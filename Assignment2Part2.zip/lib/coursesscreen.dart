import 'package:assigment3/coursrbutton.dart';
import 'package:assigment3/coursrdata.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CoursesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 0, 43, 106),
        title: Text("RouteAppOne"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView(
                children: [
                  CoursrButton(
                    courseData: CourseData("Android.jpeg", "Android Course"),
                  ),
                  CoursrButton(
                    courseData: CourseData("IOS.jpeg", "IOS Course"),
                  ),
                  CoursrButton(
                    courseData: CourseData("fullStack.jpeg", "FullStack Course"),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
